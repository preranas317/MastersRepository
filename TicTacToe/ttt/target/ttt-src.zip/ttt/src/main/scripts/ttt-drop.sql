drop table savedgames;
drop table board1;
drop table games;
drop table authorities;
drop table players;

drop sequence hibernate_sequence;










